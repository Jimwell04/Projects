package com.jimz.grade.average.calculator;

import java.util.Scanner;

public class GradeAverageCalculator {

  public static void main(String[] args) {
  
  Scanner scan = new Scanner(System.in);
  
  System.out.println("        GRADE AVERAGE CALCULATOR                      ");
  
  System.out.println();
  
  System.out.println("QUARTER 1");
  
  float filipino_q1;
  float english_q1;
  float math_q1;
  float science_q1;
  float ap_q1;
  float esp_q1;
  float tle_q1;
  float music_q1;
  float arts_q1;
  float pe_q1;
  float health_q1;
  
  System.out.print("Filipino                           : ");
  filipino_q1 = scan.nextFloat();
  
  System.out.print("English                            : ");
  english_q1 = scan.nextFloat();
  
  System.out.print("Math                               : ");
  math_q1 = scan.nextFloat();
  
  System.out.print("Science                            : ");
  science_q1 = scan.nextFloat();
  
  System.out.print("Aralin Panlipunan (AP)             : ");
  ap_q1 = scan.nextFloat();
  
  System.out.print("Edukasyon Sa Pagpapakatao (ESP)    : ");
  esp_q1 = scan.nextFloat();
  
  System.out.print("Technology and Livelihood Education: ");
  tle_q1 = scan.nextFloat();
  
  System.out.println();
  System.out.println("MAPEH");
  
  System.out.print("Music                              : ");
  music_q1 = scan.nextFloat();
  
  System.out.print("Arts                               : ");
  arts_q1 = scan.nextFloat();
  
  System.out.print("Physical Education (PE)            : ");
  pe_q1 = scan.nextFloat();
  
  System.out.print("Health                             : ");
  health_q1 = scan.nextFloat();
  
  float mapeh_q1 = (music_q1 + arts_q1 + pe_q1 + health_q1) / 4;
  System.out.println("MAPEH Average                      : " + mapeh_q1);
  
  System.out.println();
  
  float quarter1 = (filipino_q1 + english_q1 + math_q1 + science_q1 + ap_q1 + esp_q1 + tle_q1 + mapeh_q1 ) / 8;
  
  System.out.println("QUARTER 1 AVERAGE                  : " + quarter1);
  
  System.out.println();
  
  System.out.println("QUARTER 2");
  
  float filipino_q2;
  float english_q2;
  float math_q2;
  float science_q2;
  float ap_q2;
  float esp_q2;
  float tle_q2;
  float music_q2;
  float arts_q2;
  float pe_q2;
  float health_q2;
  
  System.out.print("Filipino                           : ");
  filipino_q2 = scan.nextFloat();
  
  System.out.print("English                            : ");
  english_q2 = scan.nextFloat();
  
  System.out.print("Math                               : ");
  math_q2 = scan.nextFloat();
  
  System.out.print("Science                            : ");
  science_q2 = scan.nextFloat();
  
  System.out.print("Aralin Panlipunan (AP)             : ");
  ap_q2 = scan.nextFloat();
  
  System.out.print("Edukasyon Sa Pagpapakatao (ESP)    : ");
  esp_q2 = scan.nextFloat();
  
  System.out.print("Technology and Livelihood Education: ");
  tle_q2 = scan.nextFloat();
  
  System.out.println();
  System.out.println("MAPEH");
  
  System.out.print("Music                              : ");
  music_q2 = scan.nextFloat();
  
  System.out.print("Arts                               : ");
  arts_q2 = scan.nextFloat();
  
  System.out.print("Physical Education (PE)            : ");
  pe_q2 = scan.nextFloat();
  
  System.out.print("Health                             : ");
  health_q2 = scan.nextFloat();
  
  float mapeh_q2 = (music_q1 + arts_q1 + pe_q1 + health_q1) / 4;
  System.out.println("MAPEH Average                      : " + mapeh_q2);
  
  System.out.println();
  
  float quarter2 = (filipino_q2 + english_q2 + math_q2 + science_q2 + ap_q2 + esp_q2 + tle_q2 + mapeh_q2 ) / 8;
  
  System.out.println("QUARTER 2 AVERAGE                  : " + quarter2);
  
  System.out.println();
  
  System.out.println("QUARTER 3");
  
  float filipino_q3;
  float english_q3;
  float math_q3;
  float science_q3;
  float ap_q3;
  float esp_q3;
  float tle_q3;
  float music_q3;
  float arts_q3;
  float pe_q3;
  float health_q3;
  
  System.out.print("Filipino                           : ");
  filipino_q3 = scan.nextFloat();
  
  System.out.print("English                            : ");
  english_q3 = scan.nextFloat();
  
  System.out.print("Math                               : ");
  math_q3 = scan.nextFloat();
  
  System.out.print("Science                            : ");
  science_q3 = scan.nextFloat();
  
  System.out.print("Aralin Panlipunan (AP)             : ");
  ap_q3 = scan.nextFloat();
  
  System.out.print("Edukasyon Sa Pagpapakatao (ESP)    : ");
  esp_q3 = scan.nextFloat();
  
  System.out.print("Technology and Livelihood Education: ");
  tle_q3 = scan.nextFloat();
  
  System.out.println();
  System.out.println("MAPEH");
  
  System.out.print("Music                              : ");
  music_q3 = scan.nextFloat();
  
  System.out.print("Arts                               : ");
  arts_q3 = scan.nextFloat();
  
  System.out.print("Physical Education (PE)            : ");
  pe_q3 = scan.nextFloat();
  
  System.out.print("Health                             : ");
  health_q3 = scan.nextFloat();
  
  float mapeh_q3 = (music_q3 + arts_q3 + pe_q3 + health_q3) / 4;
  System.out.println("MAPEH Average                      : " + mapeh_q3);
  
  System.out.println();
  
  float quarter3 = (filipino_q3 + english_q3 + math_q3 + science_q3 + ap_q3 + esp_q3 + tle_q3 + mapeh_q3 ) / 8;
  
  System.out.println("QUARTER 3 AVERAGE                  : " + quarter3);
  
  System.out.println();
  
  System.out.println("QUARTER 4");
  
  float filipino_q4;
  float english_q4;
  float math_q4;
  float science_q4;
  float ap_q4;
  float esp_q4;
  float tle_q4;
  float music_q4;
  float arts_q4;
  float pe_q4;
  float health_q4;
  
  System.out.print("Filipino                           : ");
  filipino_q4 = scan.nextFloat();
  
  System.out.print("English                            : ");
  english_q4 = scan.nextFloat();
  
  System.out.print("Math                               : ");
  math_q4 = scan.nextFloat();
  
  System.out.print("Science                            : ");
  science_q4 = scan.nextFloat();
  
  System.out.print("Aralin Panlipunan (AP)             : ");
  ap_q4 = scan.nextFloat();
  
  System.out.print("Edukasyon Sa Pagpapakatao (ESP)    : ");
  esp_q4 = scan.nextFloat();
  
  System.out.print("Technology and Livelihood Education: ");
  tle_q4 = scan.nextFloat();
  
  System.out.println();
  System.out.println("MAPEH");
  
  System.out.print("Music                              : ");
  music_q4 = scan.nextFloat();
  
  System.out.print("Arts                               : ");
  arts_q4 = scan.nextFloat();
  
  System.out.print("Physical Education (PE)            : ");
  pe_q4 = scan.nextFloat();
  
  System.out.print("Health                             : ");
  health_q4 = scan.nextFloat();
  
  float mapeh_q4 = (music_q4 + arts_q4 + pe_q4 + health_q4) / 4;
  System.out.println("MAPEH Average                      : " + mapeh_q4);
  
  System.out.println();
  
  float quarter4 = (filipino_q4 + english_q4 + math_q4 + science_q4 + ap_q4 + esp_q4 + tle_q4 + mapeh_q4 ) / 8;
  
  System.out.println("QUARTER 4 AVERAGE                  : " + quarter4);
  
  System.out.println();
  
  float generalAverage = (quarter1 + quarter2 + quarter3 + quarter4) / 4;
  
  System.out.println("GENERAL AVERAGE                    : " + generalAverage);
   
  }
}
