package com.jimz.onek.kiss;

public class onekKiss {

  public static void main(String[] args) {
  
  for (int i = 1; i <= 1000; i++) {
    
    System.out.println(i + ". Muwaaaa 😘");
    
  }
   
  }
}
