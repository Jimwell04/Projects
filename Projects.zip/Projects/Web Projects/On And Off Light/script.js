function On (){
				document.getElementById("image").src = "Light on.png";
}
function Off (){
				document.getElementById("image").src= "Light off.png";
}