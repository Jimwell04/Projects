function setup() {
  
  createcanvas(400,400);
  // error
  
  
  
  print("Hello, World");
  
}

function draw() {
  
  background(0);
  
}