// Created by Jimwell Ibay
// Source: https://examplewebsite.com/


function setup() {
  
  createCanvas(400,400);
  
}

function draw() {
  
  background(0);
  
  // This is comment
  
 // fill(0,255,0);
  rect(200,200,200,200);
 //     x   y   w   h
  rect(0,0,200,200);
 //    x y  w   h

}