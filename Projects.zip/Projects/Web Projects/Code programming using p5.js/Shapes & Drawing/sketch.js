function setup() {
  
  createCanvas(400,400);
  //            w   h
  
}

function draw() {
  
  background(0,25,125);
  
  triangle(150,140,125,190,190,190);
  //       x1   y1  x2  y2  x3  y3
  
  square(133,202,50,10);
  //     x    y   w  h
  
  circle(222,160,50,50);
  //      x   y   w  h 
  
  rect(200,200,50,50);
  //    x   y   w  h
  
}

