//Function 

function barf() {
				document.getElementById("sidebar").style.left = "0px";
	
document.getElementById("fw").style.marginLeft = "-23px";			
		
}

function barfl() {
				document.getElementById("sidebar").style.left = "-115px";

document.getElementById("fw").style.marginLeft = "-85px";		

}

/*function beta() {
				alert("FINDERWEB Beta 1.1.7 \nWellcome to first beta test of FINDERWEB this is beta 1.1.7\n \n \n Beta List: \n FINDERWEB Beta 1.1.0 \n FINDERWEB Beta 1.1.1  \n FINDERWEB Beta 1.1.2 \n FINDERWEB Beta 1.1.3 \n FINDERWEB Beta 1.1.4 \n FINDERWEB Beta 1.1.5 \n FINDERWEB Beta 1.1.6 \n FINDERWEB Beta 1.1.7 \n \n \nBeta means that an app is still in the development stages and not the final version. The app developer releases the beta version to let the public test the app and then provide feedback to the developer. Some types of beta apps are released to everyone, such as mobile apps that are available for download, but other apps are available only to a select group of people who are designated to test the apps.");
}*/

//Recoder function 
console.log("JavaScript is running! \n FINDERWEB Beta 1.1.0 \n FINDERWEB Beta 1.1.1  \n FINDERWEB Beta 1.1.2 \n FINDERWEB Beta 1.1.3 \n FINDERWEB Beta 1.1.4 \n FINDERWEB Beta 1.1.5 \n FINDERWEB Beta 1.1.6 \n FINDERWEB Beta 1.1.7 \n FINDERWEB Beta 1.1.8 \n Fix bug \n Remove the text decoration of link elements \n Fix Entertainment Website in the categories \n New sidebar and sidebar button color \n New sidebar width size (115pixel) \n New FINDERWEB top image icon function \n New FINDERWEB top image icon Animation \n FINDERWEB Beta 1.1.9 \n New categories page \n Fix amazon description \n New button design \n FINDERWEB 1.2.0 \n New pages \n New text link function \n New eCommerce Website categories \n FINDERWEB 1.2.1 \n New Business Website categories \n New Entertainment Website categories \n FINDERWEB Beta 1.2.2 \n New Portfolio Website categories \n FINDERWEB Beta 1.2.3 \n New main design \n New copyright design \n New page 1 design \n FINDERWEB Beta 1.2.4 \n New categories design \n New Nonprofit Website categories \n FINDERWEB Beta 1.2.5 \n Finish all categories \n FINDERWEB 1.2.6 \n New beta page \n New beta \n FINDERWEB 1.2.7 \n New page \n FINDERWEB 1.2.8 \n Change Beta Description \n");
console.log("Release-FBETA 1.1.7 \n https://mega.nz/file/HTYzgShR#84J2hjYbPJfhL5ORAgBew1bRaVhDgIREMnVLm52FqD8");
console.log("Release-FBETA 1.2.6 \n https://mega.nz/file/6GAkCJjD#noP4hTDSZQw3i3VsPymzGOKs3YEk7VO7ExvxIR8PNTo");
console.log("JavaScript -Home-");

//Beta 

function writebeta() {
				
				document.write("JavaScript is running! \n FINDERWEB Beta 1.1.0 \n FINDERWEB Beta 1.1.1  \n FINDERWEB Beta 1.1.2 \n FINDERWEB Beta 1.1.3 \n FINDERWEB Beta 1.1.4 \n FINDERWEB Beta 1.1.5 \n FINDERWEB Beta 1.1.6 \n FINDERWEB Beta 1.1.7 \n FINDERWEB Beta 1.1.8 \n Fix bug \n Remove the text decoration of link elements \n Fix Entertainment Website in the categories \n New sidebar and sidebar button color \n New sidebar width size (115pixel) \n New FINDERWEB top image icon function \n New FINDERWEB top image icon Animation \n FINDERWEB Beta 1.1.9 \n New categories page \n Fix amazon description \n New button design \n FINDERWEB 1.2.0 \n New pages \n New text link function \n New eCommerce Website categories \n FINDERWEB 1.2.1 \n New Business Website categories \n New Entertainment Website categories \n FINDERWEB Beta 1.2.2 \n New Portfolio Website categories \n FINDERWEB Beta 1.2.3 \n New main design \n New copyright design \n New page 1 design \n FINDERWEB Beta 1.2.4 \n New categories design \n New Nonprofit Website categories \n FINDERWEB Beta 1.2.5 \n Finish all categories \n FINDERWEB 1.2.6 \n New beta page \n New beta");
				
}
