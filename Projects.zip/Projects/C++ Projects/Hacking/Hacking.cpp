#include <iostream>

using namespace std;

int main ()
{   
    //Hacking

        int i = 123456789 ;  
                   
    while (  123456789 == 123456789  ){
     i++ ;
     cout << i ;
    }
    
    //BY: Jimwell B. Ibay
    return 0 ;
}