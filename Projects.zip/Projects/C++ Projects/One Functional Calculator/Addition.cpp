 #include <iostream>
 using namespace std;
 int main ()
{      
      int numOne,numTwo,sum;
      cout << "Enter A Number: ";
      cin >> numOne;
      cout << "Enter Another Number: ";
      cin >> numTwo;
      sum = numOne + numTwo;
      cout << "The Awnser Is: " << sum << endl << endl;     
      cout << "By: Jimwell B. Ibay";      
      return 0;
      
}
      
     
     
     