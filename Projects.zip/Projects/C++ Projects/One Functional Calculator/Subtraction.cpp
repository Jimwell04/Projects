#include <iostream>
 using namespace std;
      int main ()
{      
      cout << "Minus" << endl << endl;
      int numOne;
      int numTwo;
      
      cout << "Enter A Number: ";
      cin >> numOne;
      
      cout << "Enter Another Number: ";
      cin >> numTwo;
      
      int sum = numOne - numTwo;
      cout << "The Awnser Is: " << sum << endl << endl;
      
      cout << "By: Jimwell B. Ibay";
      return 0;
      
}      
      
     
     
     