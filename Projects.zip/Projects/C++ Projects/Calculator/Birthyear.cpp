#include <iostream>
using namespace std;

int main()
{
	cout << "BIRT YEAR" << endl << endl;
	int x, y;
	cout << "What is the our present year" << endl;
	cin >> x;
	cout << "You'r age" << endl;
	cin >> y;
	int sum = x - y;
	cout << "You'r birt year is:" << sum << endl << endl;
	
	cout << "By: Jimwell B. Ibay";

	return 0;
}
